using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Configuration;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;

namespace LogClient
{
    /// <summary>
    /// Class for main window.
    /// </summary>
    public sealed partial class MainWindow : Window, IDisposable
    {
        /// <summary>
        /// Array with severity levels.
        /// </summary>
        private readonly string[] severityLevels = 
            new string[] { "--- All ---", "FATAL", "ERROR", "WARN", "INFO" };

        /// <summary>
        /// Are we connected.
        /// </summary>
        private bool connected;

        /// <summary>
        /// Should we receive data.
        /// </summary>
        private bool shouldReceiveData;

        /// <summary>
        /// UDP client object.
        /// </summary>
        private UdpClient server;

        /// <summary>
        /// Port number.
        /// </summary>
        private int port;

        /// <summary>
        /// Receiver delegate.
        /// </summary>
        private AsyncCallback receiveDelegate;

        /// <summary>
        /// Log collection.
        /// </summary>
        private ObservableCollection<TraceData> log = new ObservableCollection<TraceData>();

        /// <summary>
        /// Collection of categories.
        /// </summary>
        private CategoryItemCollection categories;

        /// <summary>
        /// Action to consume data from delegate.
        /// </summary>
        private Action<string> consumeDataDelegate;

        /// <summary>
        /// Filter request.
        /// </summary>
        private int filterRequest;

        /// <summary>
        /// Are we paused.
        /// </summary>
        private bool paused;

        /// <summary>
        /// Initializes a new instance of the MainWindow class.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage(
            "Microsoft.Design", 
            "CA1031:DoNotCatchGeneralExceptionTypes", 
            Justification = "propagating exception would result in a crash")]
        public MainWindow()
        {
            try
            {
                InitializeComponent();
                CollectionView view = new ListCollectionView(this.log);
                view.Filter = (item) => this.FilterItem((TraceData)item, this.filterRequest);
                this.dgLog.ItemsSource = view;
                this.port = int.Parse(
                    ConfigurationManager.AppSettings["UdpTraceListenerPort"], 
                    CultureInfo.InvariantCulture);
                this.SetConnectDisconnectText();
                this.receiveDelegate = new AsyncCallback(this.OnReceiveData);
                this.consumeDataDelegate = this.ConsumeData;
                this.cbSeverityFilter.ItemsSource = this.severityLevels;
                this.cbSeverityFilter.SelectedIndex = 0;
                this.LoadCategoryFilter();
                this.SetCategoryFilterColors();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message + "\r\n" + e.StackTrace, e.GetType().Name);
                Application.Current.Shutdown();
            }
        }

        /// <summary>
        /// Actions to be done when closing application.
        /// </summary>
        /// <param name="e">Event arguments.</param>
        protected override void OnClosing(CancelEventArgs e)
        {
            if (this.connected)
            {
                this.StopServer();
            }
            this.SaveCategoryFilter();
            base.OnClosing(e);
        }

        /// <summary>
        /// Action after clicking on "Connect" button.
        /// </summary>
        /// <param name="sender">Sender object.</param>
        /// <param name="e">Event arguments.</param>
        internal void OnButtonConnectionClick(object sender, RoutedEventArgs e)
        {
            if (this.connected)
            {
                this.StopServer();
            }
            else
            {
                this.StartServer();
            }
            this.connected = !this.connected;
            this.SetConnectDisconnectText();
        }

        /// <summary>
        /// Change label for button "Connect".
        /// </summary>
        public void SetConnectDisconnectText()
        {
            this.btnConnection.Content = this.connected ? "Disconnect" : "Connect";
        }

        /// <summary>
        /// Action after closing window.
        /// </summary>
        /// <param name="sender">Sender object.</param>
        /// <param name="e">Event arguments.</param>
        internal void OnButtonClose(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// Action after clicking on "Clear" button.
        /// </summary>
        /// <param name="sender">Sender object.</param>
        /// <param name="e">Event arguments.</param>
        internal void OnButtonClear(object sender, RoutedEventArgs e)
        {
            this.log.Clear();
        }

        /// <summary>
        /// Action after clearing search input.
        /// </summary>
        /// <param name="sender">Sender object.</param>
        /// <param name="e">Event arguments.</param>
        internal void OnClearSearch(object sender, RoutedEventArgs e)
        {
            this.txtSearch.Clear();
            this.txtSearch.Focus();
        }

        /// <summary>
        /// Action after changing severity level.
        /// </summary>
        /// <param name="sender">Sender object.</param>
        /// <param name="e">Event arguments.</param>
        internal void OnSeverityFilterSelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            this.RequestFilter();
        }

        /// <summary>
        /// Action after change in search field.
        /// </summary>
        /// <param name="sender">Sender object.</param>
        /// <param name="e">Event arguments.</param>
        internal void OnSearchTextChanged(object sender, TextChangedEventArgs e)
        {
            tbSearchHint.Visibility = 
                this.txtSearch.Text.Length > 0 ? Visibility.Hidden : Visibility.Visible;
            btnClearSearch.Visibility = 
                this.txtSearch.Text.Length > 0 ? Visibility.Visible : Visibility.Hidden;
            this.RequestFilter();
        }

        /// <summary>
        /// Action after clicking on Run/Pause button.
        /// </summary>
        /// <param name="sender">Sender object.</param>
        /// <param name="e">Event arguments.</param>
        internal void OnButtonPauseRun(object sender, RoutedEventArgs e)
        {
            this.paused = !this.paused;
            this.btnPause.Content = this.paused ? "Run" : "Pause";
        }

        /// <summary>
        /// Filter incoming requests.
        /// </summary>
        public void RequestFilter()
        {
            ++this.filterRequest;
            this.Dispatcher.BeginInvoke(
                new Action<int>((filterRequestId) =>
                    {
                        if (this.filterRequest == filterRequestId)
                        {
                            ((ListCollectionView)this.dgLog.ItemsSource).Refresh();
                        }
                    }),
                DispatcherPriority.SystemIdle,
                this.filterRequest);
        }

        /// <summary>
        /// Filter item.
        /// </summary>
        /// <param name="data">Trace data.</param>
        /// <param name="filterRequestId">Filtered request Id.</param>
        /// <returns>Should we filter this item or not.</returns>
        public bool FilterItem(TraceData data, int filterRequestId)
        {
            bool canShow = 
                (filterRequestId == this.filterRequest) && this.categories[data.Category].Active;
            if (canShow && this.cbSeverityFilter.SelectedIndex > 0)
            {
                canShow = severityLevels
                    .Skip(1)
                    .Take(this.cbSeverityFilter.SelectedIndex)
                    .Any(p => string.Equals(p, data.Severity));
            }
            if (canShow)
            {
                canShow = data.MatchesFilter(txtSearch.Text);
            }
            return canShow;
        }

        /// <summary>
        /// Start server.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage(
            "Microsoft.Design", 
            "CA1031:DoNotCatchGeneralExceptionTypes", 
            Justification = "propagating exception would result in a crash")]
        private void StartServer()
        {
            try
            {
                if (null == this.server)
                {
                    this.server = new UdpClient(this.port);
                }
                this.server.BeginReceive(this.receiveDelegate, this.server);
                this.shouldReceiveData = true;
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message + "\r\n" + e.StackTrace, e.GetType().Name);
                Application.Current.Shutdown();
            }
        }

        /// <summary>
        /// Stop server.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage(
            "Microsoft.Design", 
            "CA1031:DoNotCatchGeneralExceptionTypes",
            Justification = "propagating exception would result in a crash")]
        private void StopServer()
        {
            try
            {
                this.shouldReceiveData = false;
                this.server.Close();
                this.server = null;
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message + "\r\n" + e.StackTrace, e.GetType().Name);
                Application.Current.Shutdown();
            }
        }

        /// <summary>
        /// We are receiving data.
        /// </summary>
        /// <param name="result">Async result.</param>
        private void OnReceiveData(IAsyncResult result)
        {
            UdpClient serverState = (UdpClient)result.AsyncState;
            if (this.shouldReceiveData)
            {
                IPEndPoint remoteEP = null;
                byte[] bytes = serverState.EndReceive(result, ref remoteEP);
                string entry = Encoding.ASCII.GetString(bytes);
                this.Dispatcher.BeginInvoke(
                    this.consumeDataDelegate, DispatcherPriority.Input, entry);
                this.StartServer();
            }
        }

        /// <summary>
        /// Parse incoming data.
        /// </summary>
        /// <param name="entry">Entry string.</param>
        [System.Diagnostics.CodeAnalysis.SuppressMessage(
            "Microsoft.Design", 
            "CA1031:DoNotCatchGeneralExceptionTypes", 
            Justification = "exception would result in a crash")]
        private void ConsumeData(string entry)
        {
            if (!string.IsNullOrEmpty(entry))
            {
                string[] parts = entry.Split('~');
                try
                {
                    TraceData data = new TraceData(parts);
                    if (!this.categories.Contains(data.Category))
                    {
                        this.categories.Add(new CategoryItem(data.Category, true));
                    }
                    this.log.Add(data);
                    if (!this.paused)
                    {
                        this.dgLog.ScrollIntoView(data);
                    }
                }
                catch (Exception e)
                {
                    Debugger.Break();
                    Console.WriteLine(e.Message);
                }
            }
        }

        /// <summary>
        /// Action after clicking on category filter.
        /// </summary>
        /// <param name="sender">Sender object.</param>
        /// <param name="e">Event arguments.</param>
        internal void OnCategoryFilterClick(object sender, RoutedEventArgs e)
        {
            Window wnd = new CategoryFilter(this.categories);
            wnd.Owner = this;
            wnd.ShowDialog();
            this.SetCategoryFilterColors();
            this.RequestFilter();
        }

        /// <summary>
        /// Set category filters on a list.
        /// </summary>
        private void SetCategoryFilterColors()
        {
            this.btnCategoryFilter.Background = 
                this.categories.Any(p => !p.Active) ? Brushes.Yellow : Brushes.Transparent;
        }

        /// <summary>
        /// Save the state of category filter.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage(
            "Microsoft.Design", 
            "CA1031:DoNotCatchGeneralExceptionTypes", 
            Justification = "propagating exception would lead to a crash")]
        private void SaveCategoryFilter()
        {
            try
            {
                using (FileStream storage = 
                    new FileStream("categories.bin", FileMode.OpenOrCreate, FileAccess.ReadWrite))
                {
                    BinaryFormatter formatter = new BinaryFormatter();
                    formatter.Serialize(storage, this.categories);
                }
            }
            catch
            {
            }
        }

        /// <summary>
        /// Load category filter.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage(
            "Microsoft.Design", 
            "CA1031:DoNotCatchGeneralExceptionTypes", 
            Justification = "propagating exception would lead to a crash")]
        private void LoadCategoryFilter()
        {
            if (File.Exists("categories.bin"))
            {
                try
                {
                    using (FileStream storage = 
                        new FileStream("categories.bin", FileMode.Open, FileAccess.Read))
                    {
                        BinaryFormatter formatter = new BinaryFormatter();
                        this.categories = (CategoryItemCollection)formatter.Deserialize(storage);
                    }
                }
                catch
                {
                }
            }
            this.categories = this.categories ?? new CategoryItemCollection();
        }

        #region IDisposable Members

        public void Dispose()
        {
            this.StopServer();
            GC.SuppressFinalize(this);
        }

        #endregion

        private void OnMouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            DataGrid dg = (DataGrid)sender;
            if (null != dg.CurrentCell)
            {
                TraceData data = (TraceData)dg.CurrentItem;
                if (null != data)
                {
                    if (dg.CurrentCell.Column == dg.Columns[1])
                    {
                        this.txtSearch.Text = data.TraceId;
                    }
                    else
                    {
                        var dlg = new EntryDetails(data);
                        dlg.Owner = this;
                        dlg.WindowStartupLocation = WindowStartupLocation.CenterOwner;
                        dlg.Show();
                    }
                }
            }
        }
    }
}
